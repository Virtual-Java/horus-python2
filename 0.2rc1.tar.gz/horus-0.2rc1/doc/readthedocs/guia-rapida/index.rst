.. _sec-guia-rapida:

Guía rápida
===========

.. toctree::
   :maxdepth: 2

   introduccion.rst
   wizard.rst
   escaneado.rst
