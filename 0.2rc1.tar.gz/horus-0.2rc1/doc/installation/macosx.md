# Horus installation in Mac OS X ![][macosx-logo]

[return to Home](../../README.md)

### Version 0.2 beta4

Download Horus installer:

* [Horus 0.2b4 installer](https://github.com/bqlabs/horus/releases/download/0.2b4/Horus_0.2b4.dmg)

Execute the installer and drag Horus icon into *Applications*

Also, you need to update your FTDI drivers:

* [FTDI USB Drivers](http://www.ftdichip.com/Drivers/VCP/MacOSX/FTDIUSBSerialDriver_v2_3.dmg)

Reboot the computer to apply the changes.

[macosx-logo]: ../images/macosx.png
